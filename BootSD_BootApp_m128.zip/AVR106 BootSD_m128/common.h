#ifndef COMMON_H
#define COMMON_H

//#define PRINT_LCD   1
//#define DEBUG_PROTEUS   1
//#define PRINT_LCD_DEBUG   1


#define PETITFATFS  1

#include <mega128.h>
/*
//#include <mega328p.h>
//#include <mega64.h>

#include <stdlib.h>

#include <stdio.h>
// Standard Input/Output functions
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "integer.h"
//#include "avr910.h"
#include <delay.h>
//#include "mycode.h"

*/
#include "mysdcard.h"


#endif