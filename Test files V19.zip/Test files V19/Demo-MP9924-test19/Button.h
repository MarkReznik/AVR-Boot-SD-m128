extern unsigned char Key; 
char TestButton(void);
char GetButton(void);