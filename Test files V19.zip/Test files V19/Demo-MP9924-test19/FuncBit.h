unsigned char GetFirstBit(unsigned char Word);  // return number of first bit

unsigned char GetBit(unsigned char Index);  // return byte with first bit up

void cpyBit(char* str1,char Bit1,char* str2,char Bit2);

void ClearBit(char* str,char bit1);

//unsigned char ClearFirstBit(unsigned char Key);  //clear first bit from byte
