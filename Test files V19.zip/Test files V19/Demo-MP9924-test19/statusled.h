extern unsigned char StatusLed[8];           // array for status of leds   

void DisplayLed(char led,char Status); 
void StatusKeybordLed(void);