
void DisplayTimer(char num); 
char EnterTimer(char Button, char NextCode);
void Write_Timer(char num);   
void Read_Timer(void);
void TestTimer(char Week,char Hour, char Min);  
void Timer_Test(char TimerArm);  