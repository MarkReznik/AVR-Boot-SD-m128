extern char FlagTech , FlagTranslate;
extern unsigned int CounterTranslate;
extern unsigned char NormalTec;

void String(unsigned int NumOfStr,char* str);
void FuncNumber(unsigned char Num,char* str);
void FuncNumberH(unsigned char Num,char* str);
void HebruSrting(char *str);
void ChangeSrting(char *str);


extern unsigned char fourline,status,EnglishMode,List,CounterRing,Bits_CNT1,PxyDirDone;
extern unsigned short Dsp_Connect_T;  // New 2.05 version change
extern unsigned int TimeConectedWithApp;
extern unsigned char Pxy_Timer,Tst_Exist;//PXYOO
extern unsigned char SwapLine23_12;